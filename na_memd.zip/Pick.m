function [ICC,ICC_main] = Pick

% choose the ICC sets and main ICC
ICC = input('Input the number of ICCs:');
ICC_main = input('Input the number of main ICCs:');