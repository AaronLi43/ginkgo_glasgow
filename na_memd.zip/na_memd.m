function  [ave_imfs_result] = na_memd( input_data,level_noise,noise_channel_num ,en_num)

imf_result = cell(en_num ,1);
sum_imf_result = cell(1 ,1);
ave_imfs_result = cell(1 ,1);

[len_inp,wid_inp] = size(input_data);
channel_num = wid_inp;

%% Calculation
for i = 1:en_num

inp_noise = level_noise * randn(len_inp,noise_channel_num);

input_cha_noi(:,1:channel_num) = input_data(:,1:channel_num);
input_cha_noi(:,channel_num+1:channel_num+noise_channel_num) = inp_noise(:,1:noise_channel_num);    
    
imfs = memd(input_cha_noi);  %IMF selection

[x,y,~] = size(imfs);
ycount(i) = y; 
   for j = 1:x
       imf_result{i,j} = reshape(imfs(j,:,:),size(imfs,2),length(input_cha_noi));
   end
end

y = min(ycount);

[imf_result] = uniformize(imf_result,x,y,ycount);


for i =1:x 
sum_imf_result{1,i} = imf_result{1,i};
end


for i = 2:en_num % the two following loops are adjusted by changing the inner loops into slicing which can accelerate the calculation
    for j = 1:x
         
                 sum_imf_result{1,j}(1:y,1:len_inp) = sum_imf_result{1,j}(1:y,1:len_inp)+imf_result{i,j}(1:y,1:len_inp); 
           
    end
end


for j = 1:x
         
                 ave_imfs_result{1,j}(1:y,1:len_inp) = sum_imf_result{1,j}(1:y,1:len_inp)/en_num; 
            
end

function  [imf_result] = uniformize (imf_result,x,y,ycount)
for i = 1:size(ycount)
    for j = 1:x
       if ycount(i)>y
          for k = 1: ycount(i)-y
               imf_result{i,j}(y,:) = imf_result{i,j}(y,:)+imf_result{i,j}(y+k,:);
          end
     end
    end
end



    
    
