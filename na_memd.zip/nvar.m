function nv=nvar(imf)
imf = imf';
% Calculate variance
v=var(imf);

% Calculate normalized variance
nv=v/sum(v);
nv = nv';
end
