function [matrix, ang_1, ang_2] = PLseries(imf1, imf2)
% **************
% Cauculate average instantaneous phases and frequencies of IMF 
% Input: imf1,imf2: IMFs decomposed from two signals
% Output: 
% matrix: -IN COLUMNS- Average instantaneous frequency of imf1
%            , average instantaneous frequency of imf2, difference of the av-
%            erage instantaneous phase between two imfs   -INROWS- IMFs
%***************

% The frequency of the original signal, please change it according to
% the signal you use on condition that you need to use the frequency
fs = 2000;
av_fre1 = zeros(size(imf1,1),1);
av_fre2 = zeros(size(imf1,1),1);
difference = zeros(size(imf1,1),1);

for k=1:size(imf1,1)
    % Hilbert transform to find the instantaneous phase of the k-th IMF
    ang1=angle(hilbert(imf1(k,:)'));
    ang2=angle(hilbert(imf2(k,:)')); 
    un_ang1 = unwrap(ang1);
    un_ang2 = unwrap(ang2);
    
    ang_1{1,k} =ang1;
    ang_2{1,k} =ang2;
    % Average instantaneous phase
    av_ang1 = mean(un_ang1);
    av_ang2 = mean(un_ang2);
    
    % Phase difference between imf1 and imf2
     difference(k) = abs(av_ang1 - av_ang2);
   
    fre1 = abs(diff(un_ang1) / (2*pi)*fs);
    fre2 = abs(diff(un_ang2) / (2*pi)*fs);
    
    % Average instantaneous frequency
    av_fre1(k) = mean(fre1);
    av_fre2(k) = mean(fre2); 
    matrix = [av_fre1,av_fre2,difference];
end
end