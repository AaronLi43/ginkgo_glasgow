function [causal_matrix] = causal_decomposition(ICC, ICC_main, input, imf_Result, level_noise, noise_channel_num, en_num)
% Input: ICC set
% Output: causal_matrix

input = input';
channel1 = 1;
channel2 = 2;
imfsize=size(ICC,1);

imfs1 = imf_Result{1,channel1};
imfs2 = imf_Result{1,channel2};


% Initiate phase vectors
p12=zeros([imfsize 1]);
p21=zeros([imfsize 1]);
input1 = input;
input2 = input;

imfss1 = imfs1(ICC,:);
imfss2 = imfs2(ICC,:);

% Calculate phase coherence between paired IMFs
[ps,~]=phasefcimf(imfss1,imfss2);

% Calculate variance of IMFs 
v1=nvar(imfss1);
v2=nvar(imfss2);

% Remove an IMF and do the redecomposition by NA-MEMD method
s1r=input(channel1,:)-imfs1(ICC_main,:);
s2r=input(channel2,:)-imfs2(ICC_main,:);

input1(channel1,:) = input(channel1,:);
input1(channel2,:) = s2r;
imfsr1 = na_memd(input1',level_noise,noise_channel_num,en_num);
imfsr11 = imfsr1{1,channel1};
imfsr12 = imfsr1{1,channel2};

input2(channel1,:) = s1r;
input2(channel2,:) = input(channel2,:);
imfsr2 = na_memd(input2',level_noise,noise_channel_num,en_num);
imfsr21 = imfsr2{1,channel1};
imfsr22 = imfsr2{1,channel2};

% Recalculate phase coherence between paired IMFs
ps12=phasefcimf(imfsr11(ICC,:),imfsr12(ICC,:));
ps21=phasefcimf(imfsr21(ICC,:),imfsr22(ICC,:));

p12=sqrt(sum(v1.*v2.*(ps12-ps).^2)/sum(v1.*v2));
p21=sqrt(sum(v1.*v2.*(ps21-ps).^2)/sum(v1.*v2));

% Calculate relative causal strengths from absolute causal strengths (p12 and p21)
% The output is 4 by 1 matrix
% The first column indicates relative causal strength from time series 1 to 2
% The second column indicates relative causal strength from time series 2 to 1
% The third column indicates absolute causal strength from time series 1 to 2
% The fourth column indicates absolute causal strength from time series 2 to 1
% 
if p12<0.05 && p21<0.05
    alpha=1;
else
    alpha=0;
end
% Exception detection: when p12 and p21 are both smaller than 0.05, the two signals have no cause and effect
causal_matrix = [(alpha+p12)/(2*alpha+p12+p21) (alpha+p21)/(2*alpha+p12+p21) p12 p21];

end






