function [pci,pdi] = pscoherence(phasediff)

% Transform phase difference to a complex plane with radius of one
z=exp((phasediff)*sqrt(-1));

% Phase coherence
pcv=sum(z)/length(z);
pci=abs(pcv);

% Phase shift (in degree)
pdi=angle(pcv)/pi*180;

end