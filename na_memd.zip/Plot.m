function Plot(imf_num,input_len,tmpResult,peakMatrix,ang_1,ang_2)
% Output peakMatrix and draw IMFs and phase images
disp('peakMatrix');
disp(peakMatrix);

  figure
  for i = 1:imf_num
    ii = ceil(sqrt(imf_num));
    subplot(ii,ii,i),plot(tmpResult{1,1}(i,:));
    hold on;
    subplot(ii,ii,i),plot(tmpResult{1,2}(i,:));
    title('IMF', i);
    xlim([0,input_len]);
  end
  
    figure
  for i = 1:imf_num
    ii = sqrt(imf_num);
    ii = ceil(ii);
    subplot(ii,ii,i),plot(ang_1{1,i});
    hold on;
    subplot(ii,ii,i),plot(ang_2{1,i});
    title('angle', i);
    xlim([0,input_len]);
  end


