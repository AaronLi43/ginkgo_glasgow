import java.awt.EventQueue;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;


public class Test {

    private JFrame frame;
    private JTextField textField;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Test window = new Test();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Test() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);//清空布局
        
        JLabel label = new JLabel("标签");
        label.setBounds(81, 63, 61, 16);
        frame.getContentPane().add(label);
        
        JButton button = new JButton("按钮");
        button.setBounds(252, 58, 117, 29);
        frame.getContentPane().add(button);
        
        textField = new JTextField();
        textField.setText("文本框");
        textField.setBounds(81, 110, 288, 26);
        frame.getContentPane().add(textField);
        textField.setColumns(10);
        
        frame.addComponentListener(new ComponentAdapter() {//拖动窗口监听
            public void componentResized(ComponentEvent e) {  
                int whidth=frame.getWidth();//获取窗口宽度
                int height=frame.getHeight();//获取窗口高度  你也可以设置高度居中
                //将lable放在 窗口左边的1/3处
                label.setBounds(whidth/3, 63, 61, 16);//(起始点x，起始点y，宽地w，高h)  标签设置宽高不明显
                //将lable放在 窗口左边的1/2处
                button.setBounds(whidth/2, 63, 61, 16);//(起始点x，起始点y，宽地w，高h)
                //宽度始终是窗口的1/2
                textField.setBounds(81, 110, whidth/2, 26);//(起始点x，起始点y，宽地w，高h)
            }  

        }); 
        
    }

}