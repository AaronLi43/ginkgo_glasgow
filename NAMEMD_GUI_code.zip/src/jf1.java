import java.awt.EventQueue;
import Pick_imf.pick_imf;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import com.mathworks.toolbox.javabuilder.*;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JProgressBar;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class jf1 extends JFrame {
	private JPanel contentPane;
	public JPanel panel;
	public JLabel label;
	public JTextField text_start;
	public JPanel panel_1;
	public JLabel label_1;
	public JTextField text_end;
	public JPanel panel_2;
	public JLabel label_2;
	public JTextField text_end_1;
	public JPanel panel_3;
	public JLabel label_3;
	public JTextField text_end_2;
	public JPanel panel_4;
	public JLabel label_4;
	public JTextField text_end_3;
	public JPanel panel_5;
	public JLabel label_5;
	public JTextField text_end_4;
	public JPanel panel_7;
	public JLabel label_7;
	public JTextField text_end_5;
	public JProgressBar progressBar;
	public JButton btnNewButton;
	public JButton FuncButton;
	public JTable table;
	public JPanel panel_6;
	public JScrollBar sc;
	public DefaultTableModel model;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					jf1 frame = new jf1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the main frame.
	 */
	public jf1() {
		
		setTitle("IMF Calculation");
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setBounds(100, 100, 611, 350);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		panel = new JPanel();
		panel.setBounds(38, 28, 149, 43);
		contentPane.add(panel);
		panel.setLayout(null);
		
		label = new JLabel("Noise Intensity");
		label.setBounds(10, 0, 90, 43);
		panel.add(label);
		
		text_start = new JTextField();
		text_start.setBounds(115, 0, 30, 43);
		panel.add(text_start);
		text_start.setColumns(10);
		
		panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBounds(38, 95, 179, 43);
		contentPane.add(panel_1);
		
		label_1 = new JLabel("Average Noise");
		label_1.setBounds(10, 0, 90, 43);
		panel_1.add(label_1);
		
		text_end = new JTextField();
		text_end.setColumns(10);
		text_end.setBounds(114, 0, 30, 43);
		panel_1.add(text_end);

		panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBounds(195, 28, 149, 43);
		contentPane.add(panel_2);
		
		label_2 = new JLabel("Noise Channels");
		label_2.setBounds(10, 0, 90, 43);
		panel_2.add(label_2);
		
		text_end_1 = new JTextField();
		text_end_1.setColumns(10);
		text_end_1.setBounds(114, 0, 30, 43);
		panel_2.add(text_end_1);

		panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBounds(195, 95, 149, 43);
		contentPane.add(panel_3);
		
		label_3 = new JLabel("Ensembles");
		label_3.setBounds(30, 0, 90, 43);
		panel_3.add(label_3);
		
		text_end_2 = new JTextField();
		text_end_2.setColumns(10);
		text_end_2.setBounds(114, 0, 30, 43);
		panel_3.add(text_end_2);
		
		panel_4 = new JPanel();
		panel_4.setLayout(null);
		panel_4.setBounds(405, 28, 139, 43);
		contentPane.add(panel_4);
		
		label_4 = new JLabel("IMF");
		label_4.setBounds(30, 0, 90, 43);
		panel_4.add(label_4);
		
		text_end_3 = new JTextField();
		text_end_3.setColumns(10);
		text_end_3.setBounds(74, 0, 30, 43);
		panel_4.add(text_end_3);

		panel_5 = new JPanel();
		panel_5.setLayout(null);
		panel_5.setBounds(405, 95, 149, 43);
		contentPane.add(panel_5);
		
		label_5 = new JLabel("Main IMF");
		label_5.setBounds(10, 0, 90, 43);
		panel_5.add(label_5);
		
		text_end_4 = new JTextField();
		text_end_4.setColumns(10);
		text_end_4.setBounds(74, 0, 30, 43);
		panel_5.add(text_end_4);

		panel_7 = new JPanel();
		panel_7.setLayout(null);
		panel_7.setBounds(40, 156, 496, 40);
		contentPane.add(panel_7);
		
		label_7 = new JLabel("File Address");
		label_7.setBounds(10, 0, 90, 43);
		panel_7.add(label_7);
		
		text_end_5 = new JTextField();
		text_end_5.setColumns(10);
		text_end_5.setBounds(100, 5, 300, 30);
		panel_7.add(text_end_5);


		progressBar = new JProgressBar();
		progressBar.setBounds(40, 216, 496, 19);
		contentPane.add(progressBar);
		
		btnNewButton = new JButton("Run for IMF");
		btnNewButton.addActionListener(new BtnNewButtonActionListener());
		btnNewButton.setBounds(38, 251, 108, 40);
		contentPane.add(btnNewButton);

		FuncButton = new JButton("Run for Causality");
		FuncButton.addActionListener(new FuncButtonActionListener());
		FuncButton.setBounds(400, 251, 138, 40);
		contentPane.add(FuncButton);
		/**
	 * Adjust the size of components according to the size of frame
	 */
		addComponentListener(new ComponentAdapter(){
			public void componentResized(ComponentEvent e){
				int width = getWidth();
				int height = getHeight();
				
				
				panel.setBounds(38*width/611, 28*height/350, 149*width/611, 43*height/350);

				label.setBounds(10*width/611, 0*height/350, 90*width/611, 43*height/350);
				
				text_start.setBounds(115*width/611, 0*height/350, 30*width/611, 43*height/350);
				
				panel_1.setBounds(38*width/611, 95*height/350, 179*width/611, 43*height/350);

				label_1.setBounds(10*width/611, 0*height/350, 90*width/611, 43*height/350);

				text_end.setBounds(114*width/611, 0*height/350, 30*width/611, 43*height/350);

				panel_2.setBounds(195*width/611, 28*height/350, 149*width/611, 43*height/350);

				label_2.setBounds(10*width/611, 0*height/350, 90*width/611, 43*height/350);

				text_end_1.setBounds(114*width/611, 0*height/350, 30*width/611, 43*height/350);

				panel_3.setBounds(195*width/611, 95*height/350, 149*width/611, 43*height/350);

				label_3.setBounds(30*width/611, 0*height/350, 90*width/611, 43*height/350);

				text_end_2.setBounds(114*width/611, 0*height/350, 30*width/611, 43*height/350);

				panel_4.setBounds(405*width/611, 28*height/350, 139*width/611, 43*height/350);

				label_4.setBounds(30*width/611, 0*height/350, 90*width/611, 43*height/350);

				text_end_3.setBounds(74*width/611, 0*height/350, 30*width/611, 43*height/350);

				panel_5.setBounds(405*width/611, 95*height/350, 149*width/611, 43*height/350);

				label_5.setBounds(10*width/611, 0*height/350, 90*width/611, 43*height/350);

				text_end_4.setBounds(74*width/611, 0*height/350, 30*width/611, 43*height/350);

				panel_7.setBounds(40*width/611, 156*height/350, 496*width/611, 40*height/350);

				label_7.setBounds(10*width/611, 0*height/350, 90*width/611, 43*height/350);

				text_end_5.setBounds(100*width/611, 5*height/350, 300*width/611, 30*height/350);

				progressBar.setBounds(40*width/611, 216*height/350, 496*width/611, 19*height/350);

				btnNewButton.setBounds(38*width/611, 251*height/350, 108*width/611, 40*height/350);

				FuncButton.setBounds(400*width/611, 251*height/350, 138*width/611, 40*height/350);
			}
		});



	}
	private class BtnNewButtonActionListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			String t1 = text_start.getText();
			String t2 = text_end.getText();
			String t3 = text_end_1.getText();
			String t4 = text_end_2.getText();
			String t5 = text_end_5.getText();
			
			if(t1!=null&&t1!=""&&t2!=null&&t2!=""&&t2!=null&&t3!=""&&t4!=null&&t4!=""&&t5!=null&&t5!=""){
				try {
					new Thread(new Runnable() {
						
						@Override
						public void run() {
							// TODO Auto-generated method stub
							Filecopy(t1,t2,t3,t4,t5);
						}
					}).start();
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			
		}
	}
	
	private class FuncButtonActionListener implements ActionListener{

		public void actionPerformed(ActionEvent arg0){
			String t1 = text_start.getText();
			String t2 = text_end.getText();
			String t3 = text_end_1.getText();
			String t4 = text_end_2.getText();
			String t5 = text_end_3.getText();
			String t6 = text_end_4.getText();
			String t7 = text_end_5.getText();

			
			
			if(t1!=null&&t1!=""&&t2!=null&&t2!=""&&t2!=null&&t3!=""&&t4!=null&&t4!=""&&t5!=null&&t5!=""&&t6!=null&&t6!=""&&t7!=null&&t7!=""){
				try {
					new Thread(new Runnable(){

						@Override
						public void run(){
							cd(t1,t2,t3,t4,t5,t6,t7);
						}
					}).start();;
				} catch (Exception e) {
					//TODO: handle exception
					e.printStackTrace();
				}
			}
			
		}
	}
	/**
	 * Create the frame for matrix demonstration.
	 */
	public void frame1(double[][] a1){
		setTitle("IMF Matrix");
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setBounds(300, 400, 611, 500);
	
		String[] str = {"Channel Number","Average Frequency of A","Average Frequency of B","Phase Difference"};
		model = new DefaultTableModel(str,0);
		table = new JTable(model);
		JScrollPane pane = new JScrollPane(table);
		pane.setViewportView(table);
		setContentPane(pane);

		model.setRowCount(a1.length);
		for(int row=0;row<a1.length;row++){
			model.setValueAt(row+1, row, 0);
			model.setValueAt(a1[row][0], row, 1);
			model.setValueAt(a1[row][1], row, 2);
			model.setValueAt(a1[row][2], row, 3);
		}
		
	
		table.setRowHeight(30);

		setVisible(true);
	}
	/**
	 * Create the frame for causality demonstration.
	 */
	public void frame2(double[][] a1){
		String[] str = {"Relative Causality of A-B","Relative Causality of B-A","Absolute Causality of A-B","Absolute Causality of B-A"};
		setTitle("IMF Matrix");
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setBounds(300, 400, 611, 300);

		model = new DefaultTableModel(str,0);
		table = new JTable(model);
		JScrollPane pane = new JScrollPane(table);
		pane.setViewportView(table);
		setContentPane(pane);
		
		model.setRowCount(a1.length);
		for(int row=0;row<a1.length;row++){
			model.setValueAt(a1[row][0], row, 0);
			model.setValueAt(a1[row][1], row, 1);
			model.setValueAt(a1[row][2], row, 2);
			model.setValueAt(a1[row][3], row, 3);
		}
		
		table.setRowHeight(30);

		setVisible(true);



	}
	
	/**
	 * Function to output the matrix of phase difference and average frequency
	 */
	public void Filecopy(String s1,String s2,String s3,String s4,String s5){
		progressBar.setValue(0);
		jf1 frame1 = new jf1();
		if(s1.equals("")||s1==null) {
			JOptionPane.showMessageDialog(null, "The input cannot be empty");
			return;
		}
		if(s2.equals("")||s2==null) {
			JOptionPane.showMessageDialog(null, "The input cannot be empty");
			return;
		}
		if(s3.equals("")||s3==null) {
			JOptionPane.showMessageDialog(null, "The input cannot be empty");
			return;
		}
		if(s4.equals("")||s4==null) {
			JOptionPane.showMessageDialog(null, "The input cannot be empty");
			return;
		}
		if(s5.equals("")||s5==null) {
			JOptionPane.showMessageDialog(null, "The input cannot be empty");
			return;
		}
		
		Loadbar n1 = new Loadbar(progressBar);
		Thread t1 = new Thread(n1);
		imf_cal n2 = new imf_cal(s1,s2,s3,s4,s5);
		Thread t2 = new Thread(n2);

		t1.start();
		t2.start();
		while(true){
			if(!t2.isAlive()){
				t1.interrupt();
				t2.interrupt();
				break;
			}
		}

		frame1.frame1(n2.getMatrix());
		
	}
	/**
	 * Function to ouput the absolute causality and relative causality
	 */
	public void cd(String s1,String s2,String s3,String s4,String s5,String s6,String s7){
		progressBar.setValue(0);
		jf1 frame2 = new jf1();
		if(s1.equals("")||s1==null) {
			JOptionPane.showMessageDialog(null, "The input cannot be empty");
			return;
		}
		if(s2.equals("")||s2==null) {
			JOptionPane.showMessageDialog(null, "The input cannot be empty");
			return;
		}
		if(s3.equals("")||s3==null) {
			JOptionPane.showMessageDialog(null, "The input cannot be empty");
			return;
		}
		if(s4.equals("")||s4==null) {
			JOptionPane.showMessageDialog(null, "The input cannot be empty");
			return;
		}if(s5.equals("")||s5==null) {
			JOptionPane.showMessageDialog(null, "The input cannot be empty");
			return;
		}if(s6.equals("")||s6==null) {
			JOptionPane.showMessageDialog(null, "The input cannot be empty");
			return;
		}
		if(s7.equals("")||s7==null) {
			JOptionPane.showMessageDialog(null, "The input cannot be empty");
			return;
		}
		
		Loadbar n1 = new Loadbar(progressBar);
		Thread t1 = new Thread(n1);
		cd_cal1 n2 = new cd_cal1(s1,s2,s3,s4,s5,s6,s7);
		Thread t2 = new Thread(n2);

		t1.start();
		t2.start();
		while(true){
			if(!t2.isAlive()){
				t1.interrupt();
				t2.interrupt();
				break;
			}
		}
		frame2.frame2(n2.getMatrix());
		
	}
}
/**
	 * Class for loadbar
	 */
class Loadbar implements Runnable{
	private JProgressBar progressBar;
	private int n;
	public Loadbar(JProgressBar progressBar){
		this.progressBar = progressBar;
	}
	
	public void run(){
		try{
			for(n=1;;n++){
				progressBar.setValue(n);
				progressBar.setStringPainted(true);
				Thread.sleep(100);
				if(n>99){
					n = 1;
				}
			}
		}catch(InterruptedException e){
			e.printStackTrace();
			progressBar.setValue(100);
			return;
		}
	}

}
/**
	 * Class to create a thread for matrix calculation
	 */
class imf_cal implements Runnable{
	private String s1;
	private String s2;
	private String s3;
	private String s4;
	private String s5;
	private Object[] Matrix;
	private MWNumericArray output;
	private double[][] res;
	private boolean sta;
	public imf_cal(String s1,String s2,String s3,String s4,String s5){
		this.s1 = s1;
		this.s2 = s2;
		this.s3 = s3;
		this.s4 = s4;
		this.s5 = s5;
	}
	@Override
	public void run(){
		try{
		sta = false;
		pick_imf function = new pick_imf();
		Matrix = function.pickMatrix(1, Double.parseDouble(s1),Double.parseDouble(s2),Double.parseDouble(s3),Double.parseDouble(s4),s5);
		
		output = (MWNumericArray)Matrix[0];
		res = (double[][])output.toDoubleArray();
		sta = true;
		Thread.sleep(1000);
		} catch (Exception e){
			JOptionPane.showMessageDialog(null,"IMF Calculation Failed!");
			return;
		}
		finally{
			MWArray.disposeArray(output);
			
		}
	}

	public double[][] getMatrix(){
		return this.res;
	}
	public boolean getSta(){
		return this.sta;
	}
}
/**
	 * Class to create a thread for causality calculation
	 */
class cd_cal1 implements Runnable{
	private String s1;
	private String s2;
	private String s3;
	private String s4;
	private String s5;
	private String s6;
	private String s7;
	private Object[] Matrix;
	private MWNumericArray output;
	private double[][] res;
	private boolean sta;
	private MWNumericArray data = null;
	public cd_cal1(String s1,String s2,String s3,String s4,String s5,String s6,String s7){
		this.s1 = s1;
		this.s2 = s2;
		this.s3 = s3;
		this.s4 = s4;
		this.s5 = s5;
		this.s6 = s6;
		this.s7 = s7;
	}
	@Override
	public void run(){
		try{
		String str = s5.replaceAll(" +", "");
		String[] arr = str.split(",");
		data = new MWNumericArray(arr,MWClassID.DOUBLE);
		
		sta = false;
		pick_imf function = new pick_imf();
		Matrix = function.cd_cal(1, Double.parseDouble(s1),Double.parseDouble(s2),Double.parseDouble(s3),Double.parseDouble(s4),data,Double.parseDouble(s6),s7);
		
		output = (MWNumericArray)Matrix[0];
		res = (double[][])output.toDoubleArray();
		sta = true;
		Thread.sleep(1000);
		} catch (Exception e){
			JOptionPane.showMessageDialog(null,"Causality Calculation Failed!");
			return;
		}
		finally{
			MWArray.disposeArray(output);
			MWArray.disposeArray(data);
		}
	}

	public double[][] getMatrix(){
		return this.res;
	}
	public boolean getSta(){
		return this.sta;
	}
}
